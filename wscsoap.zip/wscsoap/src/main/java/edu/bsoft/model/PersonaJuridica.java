package edu.bsoft.model;

import java.util.List;

public class PersonaJuridica extends Persona{
	
	private String tipo;
	
	private List<PersonaNatural>  lstPersonaNatural;

	
	
	public List<PersonaNatural> getLstPersonaNatural() {
		return lstPersonaNatural;
	}

	public void setLstPersonaNatural(List<PersonaNatural> lstPersonaNatural) {
		this.lstPersonaNatural = lstPersonaNatural;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	

}
