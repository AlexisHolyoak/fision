package edu.bsoft.bo;

public class bo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
