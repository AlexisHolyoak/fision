package edu.bsoft.wssoap.service;

import javax.jws.WebService;

import javax.xml.ws.BindingType;

import edu.bsoft.wssoap.types.Empresa;
import edu.bsoft.wssoap.types.EstadoTransaccion;
import edu.bsoft.wssoap.types.File;
import edu.bsoft.wssoap.types.FileType;
import edu.bsoft.wssoap.types.SocioType;
//import edu.bsoft.wssoap.types.Solicitud;
import edu.bsoft.wssoap.types.SolicitudType;
import edu.bsoft.wssoap.types.TransaccionSolicitudType;


@WebService(endpointInterface = "edu.bsoft.wssoap.service.SolicitudService", portName = "portSolicitud", targetNamespace = "http://ws.soa.com/wsdl", serviceName = "WSSolicitud")
public class SolicitudWS implements SolicitudService{

	public TransaccionSolicitudType consultaSolicitud(String arg0, String arg1) {
		/*
		Empresa emp = new Empresa(); emp.setRazonSocial("Lima Peru");
		SocioType socio =  new SocioType();socio.setEmpresa(emp); socio.setNombres("MiguelSarmiento");socio.setIsRepresentante("S");
		FileType file = new FileType(); 
		//file.setSocio(socio);file.setCausal("AperturaCuenta");
		SolicitudType sol = new SolicitudType();
		sol.setFile(file);
		EstadoTransaccion estado= new EstadoTransaccion();
		estado.setCodigo("000");
		estado.setDescripcion("Transaccion Correcta");
		TransaccionSolicitudType txSolicitud= new TransaccionSolicitudType();
		txSolicitud.setEstadoTransaccion(estado);
		txSolicitud.setSolicitud(sol);
		
	
		return txSolicitud;
		*/
		return null;
	}

}
