package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="EmpresaType", namespace="http://ws.soa.com/types",propOrder={"codigo","razonSocial"} )
public class EmpresaType {
	@XmlElement(name="codigo")
	public String codigo;
	
	@XmlElement(name="razonsocial")
	public String razonSocial;

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

}
