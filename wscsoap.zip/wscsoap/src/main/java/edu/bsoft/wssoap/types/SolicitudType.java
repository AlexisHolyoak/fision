package edu.bsoft.wssoap.types;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="SolicitudType",namespace="http://ws.soa.com/types",propOrder={"id","fechaInicio","fechaCierre","estado","descripcion","causalRechazo","lstEvaluacion"})
public class SolicitudType {
	
	@XmlElement(name="id")
	private int id;
	
	@XmlElement(name="fechaInicio")
	private String fechaInicio;
	
	@XmlElement(name="fechaCierre")
	private String fechaCierre;
	
	@XmlElement(name="estado")
	private String estado;
	
	@XmlElement(name="descripcion")
	private String descripcion;
	
	@XmlElement(name="causalRechazo")
	private String causalRechazo;
	
	@XmlElement(name="lstEvaluacion")
	private List<EvaluacionType> lstEvaluacion;
	
	@XmlElement(name="file")
	private FileType file;
	
	public FileType getFile() {
		return file;
	}
	public void setFile(FileType file) {
		this.file = file;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaCierre() {
		return fechaCierre;
	}
	public void setFechaCierre(String fechaCierre) {
		this.fechaCierre = fechaCierre;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getCausalRechazo() {
		return causalRechazo;
	}
	public void setCausalRechazo(String causalRechazo) {
		this.causalRechazo = causalRechazo;
	}
	public List<EvaluacionType> getLstEvaluacion() {
		return lstEvaluacion;
	}
	public void setLstEvaluacion(List<EvaluacionType> lstEvaluacion) {
		this.lstEvaluacion = lstEvaluacion;
	}
	
	

}
