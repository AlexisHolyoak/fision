package edu.bsoft.wssoap.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jws.WebService;
import javax.servlet.jsp.tagext.IterationTag;

import edu.bsoft.interfaces.ServiceInterface;
import edu.bsoft.model.Bandeja;
import edu.bsoft.model.Documentos;
import edu.bsoft.model.Evaluacion;
import edu.bsoft.model.Situacion;
import edu.bsoft.model.Solicitud;
import edu.bsoft.service.Service;
import edu.bsoft.util.Constantes;
import edu.bsoft.wssoap.types.BandejaType;
import edu.bsoft.wssoap.types.DocumentoType;
import edu.bsoft.wssoap.types.EmpresaType;
import edu.bsoft.wssoap.types.EstadoTransaccionType;
import edu.bsoft.wssoap.types.EvaluacionType;
import edu.bsoft.wssoap.types.FileType;
import edu.bsoft.wssoap.types.ListaDocumentosType;
import edu.bsoft.wssoap.types.PersonaNaturalType;
import edu.bsoft.wssoap.types.SituacionType;
import edu.bsoft.wssoap.types.SocioType;
import edu.bsoft.wssoap.types.SolicitudType;
import edu.bsoft.wssoap.types.TransaccionSolicitudType;

@WebService(endpointInterface="edu.bsoft.wssoap.service.SolicitudesInterface", portName="portSolicitud", targetNamespace="http://ws.soa.com/aperturacuenta/wsdl")
public class SolicitudImplement implements SolicitudesInterface {
    private ServiceInterface serviceNegocio;
	public TransaccionSolicitudType consultaSolicitud(String idSolicitud) {
		// TODO Auto-generated method stub
		serviceNegocio = new Service();
		Solicitud solicitud;
		
		TransaccionSolicitudType txSolicitudType =  new TransaccionSolicitudType();;
		EstadoTransaccionType estadoTransaccionType = new EstadoTransaccionType();
		SolicitudType solicitudType;
		FileType fileType;
		SocioType socioType;
		EmpresaType empresaType;
		ListaDocumentosType documentosType;
		List<EvaluacionType> lstEvaluaciones;
		try{
		 solicitud = 	serviceNegocio.consultaSolicitud(new Integer(idSolicitud).intValue());
		 estadoTransaccionType.setCodigo(Constantes.STATUS_OK);
         estadoTransaccionType.setDescripcion(Constantes.DESC_OK);
		 txSolicitudType.setEstadoTransaccion(estadoTransaccionType);
		 
		 solicitudType = new SolicitudType();
		 solicitudType.setCausalRechazo(solicitud.getCausalRechazo());
		 solicitudType.setDescripcion(solicitud.getDescripcion());
		 solicitudType.setEstado(solicitud.getEstado());
		 solicitudType.setFechaCierre(solicitud.getFechaCierre());
		 solicitud.setFechaInicio(solicitud.getFechaInicio());
		 
		 fileType = new FileType();
		 socioType =  new SocioType();
		 empresaType =  new EmpresaType();
		 
		 
		 socioType.setIsRepresentante(solicitud.getFile().getSocio().getIsRepresentante());
		 socioType.setNombres(solicitud.getFile().getSocio().getNombre());
		 empresaType.setRazonSocial(solicitud.getFile().getSocio().getEmpresa().getNombre());
		 socioType.setEmpresa(empresaType);
		 
		 //fyles
		 fileType.setId(solicitud.getFile().getId());
		 fileType.setSocio(socioType);
		 documentosType = new ListaDocumentosType();
		 Iterator<Documentos> documentos = solicitud.getFile().getLstDocumentos().iterator();
		 List<DocumentoType> lstDocumentosType =  new ArrayList<DocumentoType>();
		 while(documentos.hasNext()){
			 DocumentoType documentoType = new DocumentoType();
			 Documentos documento = documentos.next();
			 documentoType.setDescripcion(documento.getDescripcion());
			 documentoType.setId(documento.getId());
			 lstDocumentosType.add(documentoType);
		 } 
		 
		 if(solicitud.getFile().getLstDocumentos().size()>0){
		 documentosType.setSize( solicitud.getFile().getLstDocumentos().size());
		 documentosType.setLstDocumentos(lstDocumentosType);
		 }
		 
		 fileType.setLstDocumentos(documentosType);
		 
		 
		 solicitudType.setFile(fileType);
		 
		 //evaluaciones 
		 Iterator<Evaluacion> itEvaluaciones = solicitud.getLstEvaluacion().iterator();
		 lstEvaluaciones =  new ArrayList<EvaluacionType>();
		 while(itEvaluaciones.hasNext()){
			 EvaluacionType evaluacionType=new EvaluacionType();
			 Evaluacion evaluacion = itEvaluaciones.next();
			 
			 BandejaType bandejaType = new BandejaType();
			 Bandeja bandeja = evaluacion.getBandeja();
			 
			 PersonaNaturalType colaborador = new PersonaNaturalType();
			 colaborador.setCargo(bandeja.getColaborador().getNombre());
			
			 bandejaType.setColaborador(colaborador);
			 bandejaType.setFechaAtencion(bandeja.getFechaAtencion());
			 bandejaType.setFechaIngreso(bandeja.getFechaIngreso());
			 bandejaType.setId(bandeja.getId());
			 
			 evaluacionType.setBandeja(bandejaType);
			 evaluacionType.setCausal(evaluacion.getCausal());
			 evaluacionType.setFechaFin(evaluacion.getFechaFin());
			 evaluacionType.setFechaInicio(evaluacion.getFechaInicio());
			 
			 List<SituacionType> lstSituaciones = new ArrayList<SituacionType>();
			 Iterator<Situacion> itSituaciones= evaluacion.getLsSituaciones().iterator();
			 while(itSituaciones.hasNext()){
				 SituacionType situacionType = new SituacionType();
				 Situacion situacion = itSituaciones.next();
				 situacionType.setCausal(situacion.getCausal());
				 lstSituaciones.add(situacionType);
				 situacionType= null;
				 situacion=null;
			 }
			evaluacionType.setLsSituaciones(lstSituaciones); 
			 
		 }
		  solicitudType.setLstEvaluacion(lstEvaluaciones);
		 
		 //
		  txSolicitudType.setSolicitud(solicitudType);
		  
		}catch (Exception e) {
			estadoTransaccionType.setCodigo(Constantes.STATUS_ERROR);
			estadoTransaccionType.setDescripcion(Constantes.DESC_ERROR);
		}
		
		
		return txSolicitudType;
	}

}
