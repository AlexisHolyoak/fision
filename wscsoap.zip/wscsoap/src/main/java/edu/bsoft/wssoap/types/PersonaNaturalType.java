package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="PersonaType", namespace="http://ws.soa.com/types",propOrder={"id","nombre","cargo","file"})
public class PersonaNaturalType {
    @XmlElement(name="nombre")
	private String nombre;
    
    @XmlElement(name="id")
	private int id;
    
    @XmlElement(name="cargo")
	private String cargo;
    
    @XmlElement(name="file")
	private FileType file;

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public FileType getFile() {
		return file;
	}

	public void setFile(FileType file) {
		this.file = file;
	}
	
	
}
