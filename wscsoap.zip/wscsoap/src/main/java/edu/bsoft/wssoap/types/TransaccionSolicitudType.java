package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransaccionSolicitudType", namespace = "http://ws.soa.com/types", propOrder = {"estadoTransaccion", "solicitud"})
public class TransaccionSolicitudType {
	
	@XmlElement(name = "estadotransaccion")
	private EstadoTransaccionType estadoTransaccion;
	
	@XmlElement(name = "solicitud")
	private SolicitudType solicitud;
	

	public EstadoTransaccionType getEstadoTransaccion() {
		return estadoTransaccion;
	}
	public void setEstadoTransaccion(EstadoTransaccionType estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}
	public SolicitudType getSolicitud() {
		return solicitud;
	}
	public void setSolicitud(SolicitudType solicitud) {
		this.solicitud = solicitud;
	}
	

}
