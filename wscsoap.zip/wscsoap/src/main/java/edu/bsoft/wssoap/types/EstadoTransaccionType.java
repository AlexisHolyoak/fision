package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EstadoTransaccionType", namespace = "http://ws.soa.com/types", propOrder = {"codigo", "descripcion"})
public class EstadoTransaccionType {
	@XmlElement(required = true, name = "codigo")
	private String codigo;
	@XmlElement(required = true, name = "descripcion")
	private String descripcion;

	public String getCodigo() {
		return this.codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}