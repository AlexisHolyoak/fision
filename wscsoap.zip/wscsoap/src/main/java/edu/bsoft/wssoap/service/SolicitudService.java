package edu.bsoft.wssoap.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

import edu.bsoft.wssoap.types.TransaccionSolicitudType;



@WebService(name = "SolicitudWS", targetNamespace = "http://ws.soa.com/wsdl")
public interface SolicitudService {
	@WebResult(name = "respuesta", targetNamespace = "http://ws.soa.com/wsdl")
	@RequestWrapper(localName = "datosSolicitud", targetNamespace = "http://ws.soa.com/wsdl", className = "edu.bsoft.wssoap.reqres.RequestSolicitud")
	@ResponseWrapper(localName = "respuestaSolicitud", targetNamespace = "http://ws.soa.com/wsdl", className = "edu.bsoft.wssoap.reqres.ResponseSolicitud")
	TransaccionSolicitudType consultaSolicitud(
			@WebParam(name = "file", targetNamespace = "http://ws.soa.com/wsdl") String arg0,
			@WebParam(name = "socio", targetNamespace = "http://ws.soa.com/wsdl") String arg1);
	
}
	