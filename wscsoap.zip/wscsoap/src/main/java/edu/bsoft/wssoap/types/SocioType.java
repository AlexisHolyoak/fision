package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SocioType", namespace = "http://ws.soa.com/types", propOrder = {"nombres", "isRepresentante","empresa"})
public class SocioType {
	
	@XmlElement(name = "nombres")
	private String nombres;
	@XmlElement(name = "representante")
	private String isRepresentante;
	@XmlElement(name = "empresa")
	private EmpresaType empresa;
	
	
	public EmpresaType getEmpresa() {
		return empresa;
	}
	public void setEmpresa(EmpresaType empresa) {
		this.empresa = empresa;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getIsRepresentante() {
		return isRepresentante;
	}
	public void setIsRepresentante(String isRepresentante) {
		this.isRepresentante = isRepresentante;
	}

    
	

}
