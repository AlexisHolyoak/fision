package edu.bsoft.wssoap.types;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="FileType", namespace="http://ws.soa.com/types",propOrder={"id","socio","lstDocumentos"})
public class FileType {
	
	@XmlElement(name="lstDocumentos")
	private ListaDocumentosType lstDocumentos;
	
	@XmlElement(name="id")
	private String id;
	
	@XmlElement(name="socio")
	private SocioType socio;
	
	
	
	public ListaDocumentosType getLstDocumentos() {
		return lstDocumentos;
	}
	public void setLstDocumentos(ListaDocumentosType lstDocumentos) {
		this.lstDocumentos = lstDocumentos;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public SocioType getSocio() {
		return socio;
	}
	public void setSocio(SocioType socio) {
		this.socio = socio;
	}
	 
	 

}
