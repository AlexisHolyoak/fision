package edu.bsoft.wssoap.reqres;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import edu.bsoft.model.Solicitud;
import edu.bsoft.wssoap.types.SolicitudType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"lsSolicituds"})
@XmlRootElement(name = "respuestaSolicitud")
public class ResponseLstSolicitudes {
	
	@XmlElement(name = "lsSolicituds")
	List<SolicitudType> lsSolicituds ;

	public List<SolicitudType> getLsSolicituds() {
		return lsSolicituds;
	}

	public void setLsSolicituds(List<SolicitudType> lsSolicituds) {
		this.lsSolicituds = lsSolicituds;
	}

}
