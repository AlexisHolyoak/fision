package edu.bsoft.wssoap.service;

import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

import edu.bsoft.wssoap.types.TransaccionSolicitudType;

@WebService(name="SolicitudService", targetNamespace="http://ws.soa.com/aperturacuenta/wsdl")
public interface SolicitudesInterface {
	
	@WebResult(name="respuesta",targetNamespace="http://ws.soa.com/aperturacuenta/wsdl")
	@RequestWrapper(localName="datosSolicitud", targetNamespace="http://ws.soa.com/aperturacuenta/wsdl", className="edu.bsoft.wssoap.reqres.RequestSolicitudID")
	@ResponseWrapper(localName="respuestaSolicitud", targetNamespace="http://ws.soa.com/aperturacuenta/wsdl", className="edu.bsoft.wssoap.reqres.ResponseSolicitud")
	TransaccionSolicitudType consultaSolicitud(@WebParam(name="nroSolicitud", targetNamespace="http://ws.soa.com/aperturacuenta/wsdl") String idSolicitud );

}
