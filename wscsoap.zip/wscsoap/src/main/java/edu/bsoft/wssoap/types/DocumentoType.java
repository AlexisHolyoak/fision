package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="DocumentoType",namespace="http://ws.soa.com/types", propOrder={"id","descripcion","file"})
public class DocumentoType {
	
	@XmlElement(name="id")
	private String id;
	
	@XmlElement(name="descripcion")
	private String descripcion;
	
	@XmlElement(name="file")
	private FileType file;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public FileType getFile() {
		return file;
	}
	public void setFile(FileType file) {
		this.file = file;
	}

	

}
