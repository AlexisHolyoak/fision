package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="BandejaType",namespace="http://ws.soa.com/types", propOrder={"id","fechaIngreso","fechaAtencion","colaborador"})
public class BandejaType {
	
	@XmlElement(name="id")
	private String id;
	
	@XmlElement(name="fechaIngreso")
	private String fechaIngreso;
	
	@XmlElement(name="fechaAtencion")
	private String fechaAtencion;
	
	@XmlElement(name="colaborador")
	private PersonaNaturalType colaborador;
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFechaIngreso() {
		return fechaIngreso;
	}
	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	public String getFechaAtencion() {
		return fechaAtencion;
	}
	public void setFechaAtencion(String fechaAtencion) {
		this.fechaAtencion = fechaAtencion;
	}
	public PersonaNaturalType getColaborador() {
		return colaborador;
	}
	public void setColaborador(PersonaNaturalType colaborador) {
		this.colaborador = colaborador;
	}
	

}
