package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="SituacionType", namespace="http://ws.soa.com/types", propOrder={"evaluacion","causal"})
public class SituacionType {

	@XmlElement(name="evaluacion")
	private EvaluacionType evaluacion;
	
	@XmlElement(name="causal")
	private String causal;
	
	
	public EvaluacionType getEvaluacion() {
		return evaluacion;
	}
	public void setEvaluacion(EvaluacionType evaluacion) {
		this.evaluacion = evaluacion;
	}
	public String getCausal() {
		return causal;
	}
	public void setCausal(String causal) {
		this.causal = causal;
	}
	
	
}
