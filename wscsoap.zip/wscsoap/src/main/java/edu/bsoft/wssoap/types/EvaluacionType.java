package edu.bsoft.wssoap.types;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="EvaluacionType", namespace="http://ws.soa.com/types", propOrder={"fechaInicio","fechaFin","causal","file","bandeja", "lsSituaciones"})
public class EvaluacionType {
	
	@XmlElement(name="fechaInicio")
	private String fechaInicio;
	
	@XmlElement(name="fechaFin")
	private String fechaFin;
	
	@XmlElement(name="causal")
	private String causal;
	
	@XmlElement(name="file")
	private FileType file;
	
	@XmlElement(name="bandeja")
	private BandejaType bandeja;
	
	@XmlElement(name="lsSituaciones")
    private List<SituacionType> lsSituaciones;
    
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}
	public String getCausal() {
		return causal;
	}
	public void setCausal(String causal) {
		this.causal = causal;
	}
	public FileType getFile() {
		return file;
	}
	public void setFile(FileType file) {
		this.file = file;
	}
	public BandejaType getBandeja() {
		return bandeja;
	}
	public void setBandeja(BandejaType bandeja) {
		this.bandeja = bandeja;
	}
	public List<SituacionType> getLsSituaciones() {
		return lsSituaciones;
	}
	public void setLsSituaciones(List<SituacionType> lsSituaciones) {
		this.lsSituaciones = lsSituaciones;
	}
	

}
