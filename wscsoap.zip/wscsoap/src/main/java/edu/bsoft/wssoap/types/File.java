package edu.bsoft.wssoap.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FileType", namespace = "http://ws.soa.com/types", propOrder = {"socio", "causal"})
public class File {
	@XmlElement(name = "socio")
	private SocioType socio;
	@XmlElement(name = "causal")
	private String causal;
	
	public SocioType getSocio() {
		return socio;
	}
	public void setSocio(SocioType socio) {
		this.socio = socio;
	}
	public String getCausal() {
		return causal;
	}
	public void setCausal(String causal) {
		this.causal = causal;
	}
	

}
