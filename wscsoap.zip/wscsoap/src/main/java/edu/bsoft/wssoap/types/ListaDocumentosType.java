package edu.bsoft.wssoap.types;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="ListaDocumentosType",namespace="http://ws.soa.com/types", propOrder={"size","lstDocumentos"})
public class ListaDocumentosType {
	
	@XmlElement(name="cantidad")
	private int size;
	
	@XmlElement(name="documentos")
	private List<DocumentoType> lstDocumentos;

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public List<DocumentoType> getLstDocumentos() {
		return lstDocumentos;
	}

	public void setLstDocumentos(List<DocumentoType> lstDocumentos) {
		this.lstDocumentos = lstDocumentos;
	}
	
	

}
