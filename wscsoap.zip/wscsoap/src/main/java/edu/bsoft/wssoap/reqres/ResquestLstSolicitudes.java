package edu.bsoft.wssoap.reqres;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="", propOrder={"pag","cantidad"})
public class ResquestLstSolicitudes {
	
	@XmlElement(name="pagina",required=true)
	 private int pag;
	
	@XmlElement(name="cantidad",required=true)
	 private int cantidad;
	 
	public int getPag() {
		return pag;
	}
	public void setPag(int pag) {
		this.pag = pag;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	 

}
