package edu.bsoft.wssoap.reqres;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import edu.bsoft.wssoap.types.TransaccionSolicitudType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"txSolicitud"})
@XmlRootElement(name = "respuestaSolicitud")
public class ResponseSolicitud {
	@XmlElement(required = true, name = "respuesta")
	private TransaccionSolicitudType txSolicitud;

	public TransaccionSolicitudType getTxSolicitud() {
		return txSolicitud;
	}

	public void setTxSolicitud(TransaccionSolicitudType txSolicitud) {
		this.txSolicitud = txSolicitud;
	}
	

}
