package edu.bsoft.service;

import java.util.ArrayList;
import java.util.List;

import edu.bsoft.bo.SolicitudBo;
import edu.bsoft.interfaces.ServiceInterface;
import edu.bsoft.interfaces.SolicitudInterfaceBo;
import edu.bsoft.model.Solicitud;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Conexion;

public class Service implements ServiceInterface{
	

	public List<Solicitud> lstSolicitud() throws AppException {
		List<Solicitud> lstSolicitud = new ArrayList<Solicitud>();
		Conexion conexion = null;
		try{
			conexion = new Conexion();
			SolicitudInterfaceBo solicitud = new SolicitudBo(conexion);
			lstSolicitud = solicitud.lstSolicitud();
			
		}catch (Exception e) {
			try{
			conexion.closeConnection();
			}catch (Exception e2) {
				throw new AppException(e2.getMessage());
			}
		}
		
	return lstSolicitud;
	}

	public Solicitud consultaSolicitud(int in_solicitud) throws AppException {
		Solicitud solicitud = new Solicitud();
		Conexion conexion = null;
		try{
			conexion = new Conexion();
			SolicitudInterfaceBo solicitudBo = new SolicitudBo(conexion);
			solicitud = solicitudBo.consultaSolicitud(in_solicitud);
		}catch (Exception e) {
			try{
			conexion.closeConnection();
			}catch (Exception e2) {
				throw new AppException(e2.getMessage());
			}
		}
		
	return solicitud;
	}

}
