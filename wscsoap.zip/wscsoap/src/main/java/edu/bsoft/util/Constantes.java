package edu.bsoft.util;

public class Constantes {
	
	public static String STATUS_OK = "0000";
	public static String DESC_OK = "La transacci�n se ejecuto con exito";
	
	public static String STATUS_ERROR = "9999";
	public static String DESC_ERROR = "Error al ejecutar la transacci�n";

}
