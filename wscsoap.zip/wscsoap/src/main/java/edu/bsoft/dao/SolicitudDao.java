package edu.bsoft.dao;

import java.sql.CallableStatement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import edu.bsoft.interfaces.SolicitudInterfaceDao;
import edu.bsoft.model.Documentos;
import edu.bsoft.model.Evaluacion;
import edu.bsoft.model.File;
import edu.bsoft.model.PersonaNatural;
import edu.bsoft.model.Solicitud;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Conexion;
import edu.bsoft.wssoap.types.SocioType;

public class SolicitudDao implements SolicitudInterfaceDao {
	
	private static String clase ="ConsultasDao";
	private Conexion conexion;
	
	public SolicitudDao(Conexion conexion){
		this.conexion = conexion;
		
	}

	public List<Solicitud> lstSolicitud() throws AppException {
		List<Solicitud> lstSolicitud = new ArrayList<Solicitud>();
		CallableStatement cstmt =null;
		ResultSet result = null;
		String SQL = "{? = call esdbempresarial.fn_obtener_solicitudes() }";
		try{
			cstmt = this.conexion.getConnection().prepareCall(SQL);
			cstmt.registerOutParameter(1, Types.OTHER);
			cstmt.execute();
			result = (ResultSet)cstmt.getObject(1);
			while(result.next()){
				Solicitud solicitud = new Solicitud();
				solicitud.setId(result.getInt("codigo"));
				File file = new File();
				file.setId(new Integer(result.getInt("file")).toString());
				PersonaNatural socio =  new PersonaNatural();
				socio.setId(result.getInt("socio"));
				file.setSocio(socio);
				solicitud.setFile(file);
				solicitud.setFechaInicio(result.getString("fechainicio"));
				solicitud.setFechaCierre(result.getString("fechacierre"));
				solicitud.setEstado(result.getString("estado"));
				solicitud.setDescripcion(result.getString("descripcion"));
				solicitud.setCausalRechazo(result.getString("causalrechazo"));
				lstSolicitud.add(solicitud);
				socio=null;
				file=null;
				solicitud = null;
				
			}
			
			
		}catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
		}catch (Exception e) {
			throw new AppException(e.getMessage());
		}finally{
			this.conexion.closeResources(null, result, null, cstmt);
		}
	
		return lstSolicitud;
	}

	public Solicitud consultaSolicitud(int in_solicitud) throws AppException {
		Solicitud solicitud = new Solicitud();
		
		List<Solicitud> lstSolicitud = new ArrayList<Solicitud>();
		CallableStatement cstmt =null;
		ResultSet result = null;
		String SQL = "{? = call esdbempresarial.fn_obtener_solicitud(?) }";
		try{
			cstmt = this.conexion.getConnection().prepareCall(SQL);
			cstmt.registerOutParameter(1, Types.OTHER);
			cstmt.setInt(2, in_solicitud);
			cstmt.execute();
			result = (ResultSet)cstmt.getObject(1);
			while(result.next()){
				solicitud.setId(result.getInt("codigo"));
				File file = new File();
				file.setId(new Integer(result.getInt("file")).toString());
				PersonaNatural socio =  new PersonaNatural();
				socio.setId(result.getInt("socio"));
				file.setSocio(socio);
				solicitud.setFile(file);
				solicitud.setFechaInicio(result.getString("fechainicio"));
				solicitud.setFechaCierre(result.getString("fechacierre"));
				solicitud.setEstado(result.getString("estado"));
				solicitud.setDescripcion(result.getString("descripcion"));
				solicitud.setCausalRechazo(result.getString("causalrechazo"));				
			}
			
			
		}catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
		}catch (Exception e) {
			throw new AppException(e.getMessage());
		}finally{
			this.conexion.closeResources(null, result, null, cstmt);
		}
	
		return solicitud;
	}



}
