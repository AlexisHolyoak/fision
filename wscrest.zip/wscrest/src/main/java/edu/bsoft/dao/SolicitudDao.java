package edu.bsoft.dao;

import java.sql.CallableStatement;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import edu.bsoft.interfaces.SolicitudInterfaceDao;
import edu.bsoft.model.Documentos;
import edu.bsoft.model.Evaluacion;
import edu.bsoft.model.File;
import edu.bsoft.model.PersonaNatural;
import edu.bsoft.model.Solicitud;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Conexion;


public class SolicitudDao implements SolicitudInterfaceDao {
	
	private static String clase ="ConsultasDao";
	private Conexion conexion;
	
	public SolicitudDao(Conexion conexion){
		this.conexion = conexion;
		
	}

	public List<Solicitud> lstSolicitud() throws AppException {
		// TODO Auto-generated method stub
		return null;
	}

	public Solicitud consultaSolicitud(int solicitud) throws AppException {
		// TODO Auto-generated method stub
		return null;
	}




}
