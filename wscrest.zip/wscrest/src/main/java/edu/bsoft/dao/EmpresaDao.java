package edu.bsoft.dao;

public class EmpresaDao {

}
