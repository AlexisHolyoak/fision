package edu.bsoft.dao;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import edu.bsoft.interfaces.SituacionInterfazDao;
import edu.bsoft.model.Situacion;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Conexion;
import edu.bsoft.util.Constantes;
import edu.bsoft.util.Transaccion;

public class SituacionDao implements SituacionInterfazDao {
	
	private Conexion conexion;

	public Conexion getConexion() {
		return conexion;
	}

	public void setConexion(Conexion conexion) {
		this.conexion = conexion;
	}

	public Transaccion insertarSituacion(Situacion situacion) throws AppException {
		Transaccion tx =  new Transaccion();
		CallableStatement cstmt =null;
		String SQL = "{? = call esdbempresarial.fn_ingresar_situacion(?,?,?,?,?,?,?) }";
		try{
			cstmt = this.conexion.getConnection().prepareCall(SQL);
			cstmt.registerOutParameter(1, Types.VARCHAR);
			cstmt.setInt(2,new Integer(situacion.getEvaluacion().getBandeja().getId()).intValue());
			cstmt.setInt(3, situacion.getEvaluacion().getSolicitud().getId());
			cstmt.setInt(4, new Integer(situacion.getEvaluacion().getSolicitud().getFile().getId()).intValue());
			cstmt.setInt(5, situacion.getEvaluacion().getSolicitud().getFile().getSocio().getId());
			cstmt.setString(6, situacion.getFechaInicio());
			cstmt.setString(7, situacion.getCausal());
			cstmt.setString(8, situacion.getFechaFin());
			cstmt.execute();
			String resultado = cstmt.getString(1);
			if(resultado.equals(Constantes.STATUS_OK)){
	           tx.setCodigo(resultado);
	           tx.setDescripcion(Constantes.DESC_OK);
			}else{
				tx.setCodigo(resultado);
				tx.setDescripcion(Constantes.DESC_ERROR);
			};
		
		}catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
			
		}catch (Exception e) {
			throw new AppException(e.getMessage());
		}
		
		return tx;
	}

}
