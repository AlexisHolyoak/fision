package edu.bsoft.dao;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import edu.bsoft.interfaces.BandejaInterfazDao;
import edu.bsoft.model.Bandeja;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Conexion;
import edu.bsoft.util.Constantes;
import edu.bsoft.util.Transaccion;

public class BandejaDao implements BandejaInterfazDao{
    private Conexion conexion;
	public Transaccion insertarBandeja(Bandeja bandeja) throws AppException {
		Transaccion tx =  new Transaccion();
		CallableStatement cstmt =null;
		String SQL = "{? = call esdbempresarial.fn_ingresar_bandeja(?,?,?,?,?) }";
		try{
			cstmt = this.conexion.getConnection().prepareCall(SQL);
			cstmt.registerOutParameter(1, Types.VARCHAR);
			cstmt.setString(2,bandeja.getFechaIngreso());
			cstmt.setString(3, bandeja.getCausal());
			cstmt.setInt(4, bandeja.getColaborador().getId());
			cstmt.setString(5, bandeja.getFechaAtencion());
			cstmt.setString(6, bandeja.getEnviadopor());
			
			cstmt.execute();
			String resultado = cstmt.getString(1);
			String[] datos = resultado.split("-");
			if(datos['0'].equals(Constantes.STATUS_OK)){
	           tx.setRespuesta(datos[1]);
	           tx.setCodigo(datos['0']);
	           tx.setDescripcion(Constantes.DESC_OK);
			}else{
				tx.setCodigo(datos['0']);
				tx.setDescripcion(Constantes.DESC_ERROR);
			};
		
		}catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
			
		}catch (Exception e) {
			throw new AppException(e.getMessage());
		}
		
		return tx;
	}

}
