package edu.bsoft.bo;

import java.util.List;

import edu.bsoft.dao.SolicitudDao;
import edu.bsoft.interfaces.SolicitudInterfaceBo;
import edu.bsoft.interfaces.SolicitudInterfaceDao;
import edu.bsoft.model.Solicitud;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Conexion;

public class SolicitudBo implements SolicitudInterfaceBo {
	private SolicitudInterfaceDao solicitudDao;
	
	public SolicitudBo(Conexion conexion){
		
		this.solicitudDao = new SolicitudDao(conexion);
		
	}

	public List<Solicitud> lstSolicitud() throws AppException {
		// TODO Auto-generated method stub
		return this.solicitudDao.lstSolicitud();
	}

	public Solicitud consultaSolicitud(int solicitud) throws AppException {
		// TODO Auto-generated method stub
		return this.consultaSolicitud(solicitud);
	}

}
