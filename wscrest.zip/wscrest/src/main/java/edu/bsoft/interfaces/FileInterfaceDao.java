package edu.bsoft.interfaces;

public interface FileInterfaceDao {

}
