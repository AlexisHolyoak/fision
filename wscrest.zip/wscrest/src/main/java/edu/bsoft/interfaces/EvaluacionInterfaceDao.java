package edu.bsoft.interfaces;

import edu.bsoft.model.Evaluacion;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Transaccion;

public interface EvaluacionInterfaceDao {
	
	public Transaccion insertarEvaluacion(Evaluacion evaluacion) throws AppException;

}
