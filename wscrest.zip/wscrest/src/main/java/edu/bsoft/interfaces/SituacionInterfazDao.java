package edu.bsoft.interfaces;

import edu.bsoft.model.Situacion;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Transaccion;

public interface SituacionInterfazDao {
	
	public Transaccion insertarSituacion(Situacion situacion) throws AppException;

}
