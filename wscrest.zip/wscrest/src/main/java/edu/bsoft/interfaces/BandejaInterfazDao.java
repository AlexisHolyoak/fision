package edu.bsoft.interfaces;

import edu.bsoft.model.Bandeja;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Transaccion;

public interface BandejaInterfazDao {
	
	public Transaccion insertarBandeja(Bandeja bandeja) throws AppException;

}
