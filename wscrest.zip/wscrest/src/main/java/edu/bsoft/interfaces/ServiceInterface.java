package edu.bsoft.interfaces;

import java.util.List;


import edu.bsoft.model.Solicitud;
import edu.bsoft.util.AppException;

public interface ServiceInterface {
	
	public String createSolicitud(Solicitud solicitud) throws AppException;
	public String updateSolicitudBandeja(Solicitud solicitud);
	 public String updateSolicitudEvaluaciones(Solicitud solicitud);
}
