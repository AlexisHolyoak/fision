package edu.bsoft.interfaces;

import java.util.List;

import edu.bsoft.model.Solicitud;
import edu.bsoft.util.AppException;

public interface SolicitudInterfaceDao {
	
	public List<Solicitud> lstSolicitud() throws AppException;
	public Solicitud consultaSolicitud(int solicitud) throws AppException;

}
