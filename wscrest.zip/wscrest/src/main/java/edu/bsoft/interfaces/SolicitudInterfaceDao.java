package edu.bsoft.interfaces;



import edu.bsoft.model.Solicitud;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Transaccion;

public interface SolicitudInterfaceDao {
	
	public Transaccion insertarSolicitudDao(Solicitud solicitud) throws AppException;

}
