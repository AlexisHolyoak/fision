package edu.bsoft.interfaces;

import edu.bsoft.model.File;
import edu.bsoft.util.AppException;
import edu.bsoft.util.Transaccion;

public interface DocumentosInterfaceDao {
	
	public Transaccion insertarDocumentos(String documentos, File file) throws AppException;

}
