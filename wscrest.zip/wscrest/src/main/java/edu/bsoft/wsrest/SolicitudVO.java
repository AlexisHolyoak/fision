package edu.bsoft.wsrest;

public class SolicitudVO {
	
	//SOlicitud
	private int idSolicitud;
	private String fechaInicio;
	private String fechaCierre;
	private String estado;
	private String descripcion;
	private String causalRechazo;
	
	//FIle
	 private String idFile;
	 
	 //documetos
	 private String documentos;
	 
	//Socio
	 private String isRepresentante;
	 private String nombre;
	 private int idSocio;
	 	 
	 //Empresa
	 private String razonSocial;
	 private int idEmpresa;
	 
	 
	
	 	 

}
