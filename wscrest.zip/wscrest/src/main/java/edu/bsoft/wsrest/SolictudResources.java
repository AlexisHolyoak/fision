package edu.bsoft.wsrest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import edu.bsoft.interfaces.ServiceInterface;
import edu.bsoft.service.Service;


@Path("solicitud")
public class SolictudResources {
	
	private ServiceInterface serviceInterface;
	
	
	@POST @Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public EstadoTransacion createSolicitud(SolicitudVO solicitudVO){
		
		EstadoTransacion estadoTransaccion = new EstadoTransacion();
		
		serviceInterface = new Service();
		
		
		return estadoTransaccion;
		
	}
	
	@PUT @Path("/updatebandeja")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public EstadoTransacion updateSolicitudBandeja(SolicitudVO solicitudVO){
		
		EstadoTransacion estadoTransaccion = new EstadoTransacion();
		
		serviceInterface = new Service();
		
		//serviceInterface.updateSolicitudBandeja(solicitud);
		
		
		
		return estadoTransaccion;
		
	}
	
	@PUT @Path("/updateevaluacion")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public EstadoTransacion updateSolicitudEvaluacion(SolicitudVO solicitudVO){
		
		EstadoTransacion estadoTransaccion = new EstadoTransacion();
		
		serviceInterface = new Service();
		
		
		return estadoTransaccion;
		
	}
	
	@DELETE @Path("/updateevaluacion/{name}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public EstadoTransacion deleteSolicitud(@PathParam("id") String id){
		
		EstadoTransacion estadoTransaccion = new EstadoTransacion();
		
		serviceInterface = new Service();
		
		
		return estadoTransaccion;
		
	}

}
