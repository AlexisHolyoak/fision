package edu.bsoft.wsrest;

public class EvaluacionVO {

	
	private String fechaInicio;
	private String fechaFin;
	private String causal;
	
	private String situaciones;

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getCausal() {
		return causal;
	}

	public void setCausal(String causal) {
		this.causal = causal;
	}

	public String getSituaciones() {
		return situaciones;
	}

	public void setSituaciones(String situaciones) {
		this.situaciones = situaciones;
	}
	
	
	
	
}
