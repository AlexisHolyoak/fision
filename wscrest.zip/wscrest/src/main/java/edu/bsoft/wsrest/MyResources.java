package edu.bsoft.wsrest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
//import com.sun.jersey.spi.container.servlet.ServletContainer;
import javax.ws.rs.core.Response;

@Path("/holaWorld")
public class MyResources {
	    @GET
	    @Produces(MediaType.TEXT_PLAIN)
	    public String getIt() {
	        return "Got it!";
	    }
	    
	    @GET
	    @Path("/{name}")
	    public Response sayHello(@PathParam("name") String msg) {
	        String output = "Hello, " + msg + "!";
	        return Response.status(200).entity(output).build();
	    }
	    
	    @GET @Produces("application/json")
	    @Path("/persona") 
	    public Persona getPersona(){
	    	return new Persona("Persona", "1");
	    	
	    }
}
