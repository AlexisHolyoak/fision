package edu.bsoft.wsrest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/Persona")
public class PersonaResource {
	
	
	@GET @Produces(MediaType.APPLICATION_JSON) @Path("/finPersona")
	public Persona getPersona(){	
		return new Persona("Walter", "1");
		
	}

}
