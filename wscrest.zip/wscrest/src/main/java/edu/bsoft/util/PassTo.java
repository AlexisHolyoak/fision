package edu.bsoft.util;

import edu.bsoft.model.Bandeja;
import edu.bsoft.model.Solicitud;
import edu.bsoft.wsrest.BandejaVO;
import edu.bsoft.wsrest.SolicitudVO;

public class PassTo {
	
	
	public  Solicitud solicitudJsonToModel(SolicitudVO solicitudVo){
		Solicitud solicitud = new Solicitud();
		
		
		return solicitud;
		
	}
	
	public  Bandeja bandejaJsonToModel(BandejaVO bandejaVO){
		Bandeja bandeja = new Bandeja();
		
		
		return bandeja;
		
	}
	public  Solicitud bandejaJsonToModel(SolicitudVO solicitudVo){
		Solicitud solicitud = new Solicitud();
		
		
		return solicitud;		
	}

}
