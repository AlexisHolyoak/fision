package edu.bsoft.util;

public class Transaccion {
	
	private String codigo;
	private String descripcion;
	private String respuesta;

}
