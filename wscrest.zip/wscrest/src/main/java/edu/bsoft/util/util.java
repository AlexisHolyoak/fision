package edu.bsoft.util;

public class util {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
