package edu.bsoft.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class Conexion {
	
	Connection conn;
	
	public Conexion() throws AppException{
		DataSource ds;
		InitialContext cxt;
		try {
			cxt = new InitialContext();
			ds=(DataSource)cxt.lookup("java:/PostgresDSEmp");
			this.conn = ds.getConnection();
		} catch (NamingException ne) {
			throw new AppException(ne.getMessage());
		}catch (SQLException sqle) {
			throw new AppException(sqle.getMessage());
		}
		
		
		
	}
	
	public Connection getConnection(){
		return this.conn;
	}
	
	public void closeConnection() throws Exception{
		  this.closeResources(conn, null, null, null);
	}
	
	public void closeResources(Connection conn, ResultSet rs, Statement stmt, CallableStatement cstmt ) throws AppException{
		 if(conn !=null ){
			 try {
				 conn.close();
			} catch (SQLException sqle) {
				throw new AppException(sqle.getMessage());
			}
			 
		 }
		 
		 if(rs !=null){
			 try {
				 rs.close();
			} catch (SQLException sqle) {
				throw new AppException(sqle.getMessage());
			}
			 
			 
		 }
		 
		 if(stmt !=null){
			 try {
				 stmt.close();
			} catch (SQLException sqle) {
				throw new AppException(sqle.getMessage());
			}
			 
			 
		 }
		 if(cstmt !=null){
			 try {
				 cstmt.close();
			} catch (SQLException sqle) {
				throw new AppException(sqle.getMessage());
			}
			 
			 
		 }
	}
	
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
