package edu.bsoft.filter;

public class Filter {

}
