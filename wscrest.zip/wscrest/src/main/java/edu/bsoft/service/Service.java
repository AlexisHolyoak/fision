package edu.bsoft.service;

import edu.bsoft.interfaces.ServiceInterface;
import edu.bsoft.model.Solicitud;

public class Service implements ServiceInterface{
	


	
	public String createSolicitud(Solicitud solicitud){
		
		
		return null;
	}
	
    public String updateSolicitudBandeja(Solicitud solicitud){
		
		
		return null;
	}
    
    public String updateSolicitudEvaluaciones(Solicitud solicitud){
		
		
		return null;
	}
    
    public String deleteSolicitudEvaluaciones(Solicitud solicitud){
		
		
		return null;
	}


}