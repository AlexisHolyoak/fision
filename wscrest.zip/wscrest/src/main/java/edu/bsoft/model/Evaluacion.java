package edu.bsoft.model;

import java.util.List;

public class Evaluacion {
	
	private String fechaInicio;
	private String fechaFin;
	private String causal;
	private Solicitud solicitud;
	private Bandeja bandeja;
    private List<Situacion> lsSituaciones;
   
	
	public Solicitud getSolicitud() {
		return solicitud;
	}
	public void setSolicitud(Solicitud solicitud) {
		this.solicitud = solicitud;
	}
	public List<Situacion> getLsSituaciones() {
		return lsSituaciones;
	}
	public void setLsSituaciones(List<Situacion> lsSituaciones) {
		this.lsSituaciones = lsSituaciones;
	}
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}
	public String getCausal() {
		return causal;
	}
	public void setCausal(String causal) {
		this.causal = causal;
	}

	public Bandeja getBandeja() {
		return bandeja;
	}
	public void setBandeja(Bandeja bandeja) {
		this.bandeja = bandeja;
	}
}
