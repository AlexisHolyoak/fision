package edu.bsoft.model;

import java.util.List;

public class Bandeja {
	
	private String id;
	private String fechaIngreso;
	private String fechaAtencion;
	private String causal;
	private String enviadopor;
	

	private PersonaNatural colaborador;
	
	private List<Evaluacion> lstEvaluacion;
	
	public String getEnviadopor() {
		return enviadopor;
	}
	public void setEnviadopor(String enviadopor) {
		this.enviadopor = enviadopor;
	}
	
	public String getCausal() {
		return causal;
	}
	public void setCausal(String causal) {
		this.causal = causal;
	}
	public List<Evaluacion> getLstEvaluacion() {
		return lstEvaluacion;
	}
	public void setLstEvaluacion(List<Evaluacion> lstEvaluacion) {
		this.lstEvaluacion = lstEvaluacion;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFechaIngreso() {
		return fechaIngreso;
	}
	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	public String getFechaAtencion() {
		return fechaAtencion;
	}
	public void setFechaAtencion(String fechaAtencion) {
		this.fechaAtencion = fechaAtencion;
	}
	public Persona getColaborador() {
		return colaborador;
	}
	public void setColaborador(PersonaNatural colaborador) {
		this.colaborador = colaborador;
	}
	

}
