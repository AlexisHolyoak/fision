package edu.bsoft.model;

import java.util.List;

public class PersonaNatural extends Persona {
	
	private String cargo;
	
	private String isRepresentante;
	
	private PersonaJuridica empresa;
	
	private File file;
	
	private List<Bandeja> lstBandeja;
	

	public String getIsRepresentante() {
		return isRepresentante;
	}

	public void setIsRepresentante(String isRepresentante) {
		this.isRepresentante = isRepresentante;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public List<Bandeja> getLstBandeja() {
		return lstBandeja;
	}

	public void setLstBandeja(List<Bandeja> lstBandeja) {
		this.lstBandeja = lstBandeja;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public PersonaJuridica getEmpresa() {
		return empresa;
	}

	public void setEmpresa(PersonaJuridica empresa) {
		this.empresa = empresa;
	}
	

}
