package edu.bsoft.model;

public class model {

}
