package edu.bsoft.model;

import java.util.List;

public class File {
	
 private List<Documentos> lstDocumentos;
 private String id;
 private PersonaNatural socio;
 private String causal;
 
	public String getCausal() {
	return causal;
}
public void setCausal(String causal) {
	this.causal = causal;
}
	public PersonaNatural getSocio() {
	return socio;
}
public void setSocio(PersonaNatural socio) {
	this.socio = socio;
}
	public List<Documentos> getLstDocumentos() {
		return lstDocumentos;
	}
	public void setLstDocumentos(List<Documentos> lstDocumentos) {
		this.lstDocumentos = lstDocumentos;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

}
