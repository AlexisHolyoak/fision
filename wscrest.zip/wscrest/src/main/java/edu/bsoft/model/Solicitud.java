package edu.bsoft.model;

import java.util.List;

public class Solicitud {
	
	private int id;

	private File file;
	private String fechaInicio;
	private String fechaCierre;
	private String estado;
	private String descripcion;
	private String causalRechazo;
	
	private List<Evaluacion> lstEvaluacion;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public List<Evaluacion> getLstEvaluacion() {
		return lstEvaluacion;
	}
	public void setLstEvaluacion(List<Evaluacion> lstEvaluacion) {
		this.lstEvaluacion = lstEvaluacion;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	public String getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public String getFechaCierre() {
		return fechaCierre;
	}
	public void setFechaCierre(String fechaCierre) {
		this.fechaCierre = fechaCierre;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getCausalRechazo() {
		return causalRechazo;
	}
	public void setCausalRechazo(String causalRechazo) {
		this.causalRechazo = causalRechazo;
	}
	

}
